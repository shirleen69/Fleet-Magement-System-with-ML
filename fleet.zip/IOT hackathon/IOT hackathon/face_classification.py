import cv2
import numpy as np
import os
from tensorflow.keras.models import load_model, Sequential
from tensorflow.keras.layers import Dense, Flatten, Conv2D, MaxPooling2D, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split

def create_model():
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(224, 224, 3)),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        Flatten(),
        Dense(128, activation='relu'),
        Dropout(0.5),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

def load_employee_data(employee_data_dir):
    # ... (same as before)

def train_model(employee_data_dir, model_path, epochs=10):
    model = create_model()
    
    images, labels = load_employee_data(employee_data_dir)
    
    # Create non-employee data (you may want to replace this with actual non-employee data)
    non_employee_images = np.random.rand(len(images), 224, 224, 3) * 255
    non_employee_labels = np.zeros(len(images))
    
    # Combine employee and non-employee data
    all_images = np.concatenate([images, non_employee_images])
    all_labels = np.concatenate([labels, non_employee_labels])
    
    # Split data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(all_images, all_labels, test_size=0.2, random_state=42)
    
    # Data augmentation for training data
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True
    )
    
    # Only rescaling for validation data
    val_datagen = ImageDataGenerator(rescale=1./255)
    
    # Create generators
    train_generator = train_datagen.flow(X_train, y_train, batch_size=32)
    val_generator = val_datagen.flow(X_val, y_val, batch_size=32)
    
    # Train the model
    history = model.fit(
        train_generator, 
        epochs=epochs, 
        validation_data=val_generator,
        callbacks=[tf.keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)]
    )
    model.save(model_path)
    print(f"Model trained for {epochs} epochs and saved to {model_path}")
    return history

def load_classification_model(model_path):
    return load_model(model_path)

def classify_face(face_img, model):
    img = cv2.resize(face_img, (224, 224))
    img = img / 255.0  # Normalize the image
    img = img.reshape(1, 224, 224, 3)
    prediction = model.predict(img)
    return "Employee" if prediction[0][0] > 0.5 else "Non-employee"

def initialize_and_train_model(employee_data_dir, model_path, epochs=20):
    if not os.path.exists(model_path):
        print("Model not found. Training new model...")
        history = train_model(employee_data_dir, model_path, epochs)
    else:
        print(f"Model found at {model_path}. Loading existing model.")
        model = load_classification_model(model_path)
        # Optionally retrain the model
        retrain = input("Do you want to retrain the model? (y/n): ")
        if retrain.lower() == 'y':
            history = train_model(employee_data_dir, model_path, epochs)
        else:
            history = None
    
    return load_classification_model(model_path), history