import cv2
import numpy as np
import os
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
import dlib

# Initialize face detector and shape predictor
face_detector = dlib.get_frontal_face_detector()
shape_predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
face_recognition_model = dlib.face_recognition_model_v1("dlib_face_recognition_resnet_model_v1.dat")

def extract_face_features(face_img):
    # Detect faces
    faces = face_detector(face_img)
    if len(faces) == 0:
        return None
    
    # Get the first face
    face = faces[0]
    
    # Get facial landmarks
    shape = shape_predictor(face_img, face)
    
    # Compute face descriptor
    face_descriptor = face_recognition_model.compute_face_descriptor(face_img, shape)
    
    return np.array(face_descriptor)

def train_face_recognition_model(EMPLOYEE_DATA_DIR):
    features = []
    labels = []
    
    for employee_name in os.listdir(EMPLOYEE_DATA_DIR):
        employee_dir = os.path.join(EMPLOYEE_DATA_DIR, employee_name)
        if os.path.isdir(employee_dir):
            for img_name in os.listdir(employee_dir):
                img_path = os.path.join(employee_dir, img_name)
                img = cv2.imread(img_path)
                if img is not None:
                    face_features = extract_face_features(img)
                    if face_features is not None:
                        features.append(face_features)
                        labels.append(employee_name)
    
    # Convert labels to numerical format
    le = LabelEncoder()
    numerical_labels = le.fit_transform(labels)
    
    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(features, numerical_labels, test_size=0.2, random_state=42)
    
    # Train SVM classifier
    svm = SVC(kernel='linear', probability=True)
    svm.fit(X_train, y_train)
    
    # Evaluate the model
    y_pred = svm.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Face recognition model accuracy: {accuracy:.2f}")
    
    return svm, le

def recognize_face(face_img, model, label_encoder):
    face_features = extract_face_features(face_img)
    if face_features is None:
        return "Unknown"
    prediction = model.predict([face_features])
    employee_name = label_encoder.inverse_transform(prediction)[0]
    return employee_name

def load_face_recognition_model(MODEL_PATH):
    # Load the SVM model and LabelEncoder
    data = np.load(MODEL_PATH, allow_pickle=True)
    svm = data['svm'].item()
    le = data['label_encoder'].item()
    return svm, le

def save_face_recognition_model(MODEL_PATH, svm, label_encoder):
    # Save the SVM model and LabelEncoder
    np.savez(MODEL_PATH, svm=svm, label_encoder=label_encoder)
    print(f"Face recognition model saved to {MODEL_PATH}")