import cv2
import os
import numpy as np
from face_recognition import train_face_recognition_model, load_face_recognition_model, save_face_recognition_model
from data_capture import capture_employee_data
from face_classification import initialize_and_train_model
from monitoring import monitor_fleet
from utils import load_environment_variables
import logging

CAPACITY = 1
FACE_CASCADE_PATH = 'haarcascade_frontalface_default.xml'
MODEL_PATH = 'face_recognition_model.npz'
EMPLOYEE_DATA_DIR = 'employee_data'
CLASSIFICATION_MODEL_PATH = 'face_classification_model.h5'

def main():
    logging.basicConfig(level=logging.INFO)
    env_vars = load_environment_variables()
    
    face_cascade = cv2.CascadeClassifier(FACE_CASCADE_PATH)
    if face_cascade.empty():
        logging.error("Error loading face cascade classifier")
        return
    
    if not os.path.exists(MODEL_PATH):
        logging.warning("Face recognition model not found. You need to train the model first.")
        svm, le = None, None
    else:
        svm, le = load_face_recognition_model(MODEL_PATH)
    
    # Initialize and train (if necessary) the classification model
    classification_model, _ = initialize_and_train_model(EMPLOYEE_DATA_DIR, CLASSIFICATION_MODEL_PATH)

    while True:
        choice = input("Enter 1 to capture employee data, 2 to train models, 3 to start monitoring, or q to quit: ")
        if choice == '1':
            employee_name = input("Enter employee name: ")
            employee_id = input("Enter employee ID: ")
            capture_employee_data(employee_name, employee_id, face_cascade, EMPLOYEE_DATA_DIR)
        elif choice == '2':
            svm, le = train_face_recognition_model(EMPLOYEE_DATA_DIR)
            save_face_recognition_model(MODEL_PATH, svm, le)
            # Retrain the classification model with the new data
            epochs = int(input("Enter the number of epochs for classification model training: "))
            classification_model, history = initialize_and_train_model(EMPLOYEE_DATA_DIR, CLASSIFICATION_MODEL_PATH, epochs)
            if history:
                print(f"Final training accuracy: {history.history['accuracy'][-1]:.2f}")
                print(f"Final validation accuracy: {history.history['val_accuracy'][-1]:.2f}")
        elif choice == '3':
            if svm is None or le is None:
                logging.warning("Please train the face recognition model first before starting monitoring.")
            else:
                monitor_fleet(face_cascade, svm, le, classification_model, CAPACITY)
        elif choice.lower() == 'q':
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()