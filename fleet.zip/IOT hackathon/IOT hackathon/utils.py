import random
import requests
import os
from dotenv import load_dotenv
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def load_environment_variables():
    load_dotenv()
    return {
        'THINGSPEAK_WRITE_API_KEY': os.getenv('THINGSPEAK_WRITE_API_KEY'),
        'TELEGRAM_BOT_TOKEN': os.getenv('TELEGRAM_BOT_TOKEN'),
        'TELEGRAM_CHAT_ID': os.getenv('TELEGRAM_CHAT_ID')
    }

env_vars = load_environment_variables()
THINGSPEAK_WRITE_API_KEY = env_vars['THINGSPEAK_WRITE_API_KEY']
TELEGRAM_BOT_TOKEN = env_vars['TELEGRAM_BOT_TOKEN']
TELEGRAM_CHAT_ID = env_vars['TELEGRAM_CHAT_ID']

def simulate_gps():
    return round(random.uniform(-90, 90), 6), round(random.uniform(-180, 180), 6)

def update_thingspeak(occupancy, lat, lon):
    payload = {
        'api_key': THINGSPEAK_WRITE_API_KEY,
        'field1': occupancy,
        'field2': lat,
        'field3': lon
    }
    try:
        response = requests.get('https://api.thingspeak.com/update', params=payload, timeout=10)
        response.raise_for_status()
        logging.info("Updated ThingSpeak successfully.")
    except requests.RequestException as e:
        logging.error(f"Failed to update ThingSpeak: {e}")

def send_telegram_alert(subject, message, image_path=None):
    full_message = f"*{subject}*\n{message}"
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": full_message,
        "parse_mode": "Markdown"
    }
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        logging.info("Telegram message sent successfully.")

        if image_path:
            image_url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendPhoto"
            with open(image_path, 'rb') as image_file:
                files = {'photo': image_file}
                image_response = requests.post(image_url, data={'chat_id': TELEGRAM_CHAT_ID}, files=files)
                image_response.raise_for_status()
            logging.info("Telegram image sent successfully.")
    except requests.RequestException as e:
        logging.error(f"Error sending Telegram alert: {e}")