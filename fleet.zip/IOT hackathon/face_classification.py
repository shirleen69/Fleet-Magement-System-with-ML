import os
import cv2
import numpy as np
from tensorflow.keras.models import load_model, Sequential
from tensorflow.keras.layers import Dense, Flatten, Conv2D, MaxPooling2D, Dropout
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from sklearn.model_selection import train_test_split
import tensorflow as tf

def create_model():
    model = Sequential([
        Conv2D(32, (3, 3), activation='relu', input_shape=(224, 224, 3)),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        MaxPooling2D((2, 2)),
        Conv2D(64, (3, 3), activation='relu'),
        Flatten(),
        Dense(128, activation='relu'),
        Dropout(0.5),
        Dense(1, activation='sigmoid')
    ])
    model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
    return model

def load_employee_data(EMPLOYEE_DATA_DIR):
    images = []
    labels = []
    label_dict = {}
    label_index = 0

    # Iterate through each subdirectory in the employee data directory
    for label_name in os.listdir(EMPLOYEE_DATA_DIR):
        label_path = os.path.join(EMPLOYEE_DATA_DIR, label_name)
        
        # Check if it is a directory
        if os.path.isdir(label_path):
            if label_name not in label_dict:
                label_dict[label_name] = label_index
                label_index += 1
            
            # Load images from the subdirectory
            for img_file in os.listdir(label_path):
                img_path = os.path.join(label_path, img_file)

                # Check if the file is an image
                if img_file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    img = cv2.imread(img_path)
                    if img is not None:
                        img = cv2.resize(img, (224, 224))  # Resize images to match model input
                        images.append(img)
                        labels.append(label_dict[label_name])  # Use the corresponding label index

    # Convert lists to numpy arrays
    images = np.array(images, dtype=np.float32)
    labels = np.array(labels)

    # Normalize images
    images /= 255.0

    return images, labels

def train_model(EMPLOYEE_DATA_DIR, MODEL_PATH, epochs=10):
    model = create_model()
    
    images, labels = load_employee_data(EMPLOYEE_DATA_DIR)
    
    # Create non-employee data (you may want to replace this with actual non-employee data)
    non_employee_images = np.random.rand(len(images), 224, 224, 3) * 255
    non_employee_labels = np.zeros(len(images))
    
    # Combine employee and non-employee data
    all_images = np.concatenate([images, non_employee_images])
    all_labels = np.concatenate([labels, non_employee_labels])
    
    # Split data into training and validation sets
    X_train, X_val, y_train, y_val = train_test_split(all_images, all_labels, test_size=0.2, random_state=42)
    
    # Data augmentation for training data
    train_datagen = ImageDataGenerator(
        rescale=1./255,
        rotation_range=20,
        width_shift_range=0.2,
        height_shift_range=0.2,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True
    )
    
    # Only rescaling for validation data
    val_datagen = ImageDataGenerator(rescale=1./255)
    
    # Create generators
    train_generator = train_datagen.flow(X_train, y_train, batch_size=32)
    val_generator = val_datagen.flow(X_val, y_val, batch_size=32)
    
    # Train the model
    history = model.fit(
        train_generator, 
        epochs=epochs, 
        validation_data=val_generator,
        callbacks=[tf.keras.callbacks.EarlyStopping(patience=5, restore_best_weights=True)]
    )
    model.save(MODEL_PATH)
    print(f"Model trained for {epochs} epochs and saved to {MODEL_PATH}")
    return history

def load_classification_model(MODEL_PATH):
    return load_model(MODEL_PATH)

def classify_face(face_img, model):
    img = cv2.resize(face_img, (224, 224))
    img = img / 255.0  # Normalize the image
    img = img.reshape(1, 224, 224, 3)
    prediction = model.predict(img)
    return "Employee" if prediction[0][0] > 0.5 else "Non-employee"

def initialize_and_train_model(EMPLOYEE_DATA_DIR, MODEL_PATH, epochs=20):
    if not os.path.exists(MODEL_PATH):
        print("Model not found. Training new model...")
        history = train_model(EMPLOYEE_DATA_DIR, MODEL_PATH, epochs)
    else:
        print(f"Model found at {MODEL_PATH}. Loading existing model.")
        model = load_classification_model(MODEL_PATH)
        # Optionally retrain the model
        retrain = input("Do you want to retrain the model? (y/n): ")
        if retrain.lower() == 'y':
            history = train_model(EMPLOYEE_DATA_DIR, MODEL_PATH, epochs)
        else:
            history = None
    
    return load_classification_model(MODEL_PATH), history
