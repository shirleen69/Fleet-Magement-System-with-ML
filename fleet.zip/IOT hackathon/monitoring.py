import cv2
import time
from face_detection import detect_faces
from face_recognition import recognize_face, load_face_recognition_model
from face_classification import load_classification_model, classify_face
from utils import simulate_gps, update_thingspeak, send_telegram_alert
import logging

def monitor_fleet(face_cascade, svm_model, label_encoder, classification_model, capacity):
    # Create a directory for non-employee images
    non_employee_folder = 'non_employee_folder'
    os.makedirs(non_employee_folder, exist_ok=True)  # Create folder if it doesn't exist
    
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        logging.error("Failed to open camera")
        return
    
    cap.set(3, 640)
    cap.set(4, 480)
    font = cv2.FONT_HERSHEY_COMPLEX
    
    last_update_time = 0
    update_interval = 15  # seconds
    
    try:
        while True:
            ret, frame = cap.read()
            if not ret:
                logging.error("Failed to capture frame")
                break
            
            faces = detect_faces(frame, face_cascade)
            
            employee_count = 0
            non_employee_count = 0
            
            for (x, y, w, h) in faces:
                face_img = frame[y:y+h, x:x+w]
                
                # Recognize face using SVM model
                recognized_name = recognize_face(face_img, svm_model, label_encoder)
                
                # Classify face using CNN model
                classification_result = classify_face(face_img, classification_model)
                
                # Use classification result for display
                if classification_result == "Employee" and recognized_name != "Unknown":
                    employee_count += 1
                    label = f"{recognized_name} (Class: {classification_result})"
                else:
                    non_employee_count += 1  # Increment for Unknown and non-employees
                    label = f"Non-employee (Class: {classification_result})"
                    
                    # Save the face image for non-employees in the dedicated folder
                    non_employee_image_path = os.path.join(non_employee_folder, f"non_employee_{int(time.time())}.jpg")
                    cv2.imwrite(non_employee_image_path, face_img)

                    # Simulate GPS coordinates for alert
                    lat, lon = simulate_gps()
                    current_occupancy = employee_count + non_employee_count
                    alert_message = f"Alert! Non-employee detected."
                    # Send alert with occupancy, location, alert message, and image
                    send_telegram_alert("Non-employee Alert", alert_message, occupancy=current_occupancy, location=f"Lat: {lat}, Lon: {lon}", image_path=non_employee_image_path)
                
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.rectangle(frame, (x, y-40), (x+w, y), (0, 255, 0), -2)
                cv2.putText(frame, label, (x, y-10), font, 0.75, (255, 255, 255), 1, cv2.LINE_AA)

            current_occupancy = employee_count + non_employee_count
            
            current_time = time.time()
            if current_time - last_update_time >= update_interval:
                lat, lon = simulate_gps()
                update_thingspeak(current_occupancy, lat, lon)
                last_update_time = current_time

                # Send an alert if over capacity
                if current_occupancy > capacity:
                    alert_message = f"Alert! Over capacity. Current occupancy: {current_occupancy}."
                    send_telegram_alert("Over Capacity Alert", alert_message, occupancy=current_occupancy, location=f"Lat: {lat}, Lon: {lon}")
            
            cv2.putText(frame, f'Occupancy: {current_occupancy}/{capacity}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.imshow('Fleet Monitoring', frame)
            
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
    
    except Exception as e:
        logging.error(f"An error occurred during monitoring: {e}")
    finally:
        cap.release()
        cv2.destroyAllWindows()
