import cv2
import os
import logging
from face_detection import detect_faces

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def capture_employee_data(employee_name, employee_id, face_cascade, EMPLOYEE_DATA_DIR):
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        logging.error("Failed to open camera.")
        return

    cap.set(cv2.CAP_PROP_AUTOFOCUS, 1)
    
    output_dir = os.path.join(EMPLOYEE_DATA_DIR, f'{employee_id}_{employee_name}')
    os.makedirs(output_dir, exist_ok=True)
    
    img_count = 0
    
    while img_count < 20:  # Capture 20 images for each employee
        ret, frame = cap.read()
        if not ret:
            logging.error("Failed to capture frame.")
            break
        
        faces = detect_faces(frame, face_cascade)

        if len(faces) == 0:
            logging.warning("No faces detected in the frame.")
            cv2.putText(frame, "No faces detected", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        
        for (x, y, w, h) in faces:
            face_img = frame[y:y+h, x:x+w]
            img_path = os.path.join(output_dir, f'{img_count}.jpg')
            cv2.imwrite(img_path, face_img)
            img_count += 1
            logging.info(f"Saved image {img_count} to {img_path}")

        cv2.imshow('Employee Data Capture', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    logging.info(f"Captured {img_count} images for employee {employee_name} (ID: {employee_id})")
